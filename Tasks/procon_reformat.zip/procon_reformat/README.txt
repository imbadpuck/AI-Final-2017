Input file:
- Số n đầu tiên là số miếng
- n dòng tiếp theo miêu tả n miếng
	+ Số đầu tiên là id của miếng.
	+ Số thứ 2 là số đỉnh k của hình.
	+ k cặp số tiếp theo là tọa độ của k đỉnh theo 1 chiều nhất định (cùng chiều kim đồng hồ hoặc ngoặc chiều kim đồng hồ).
- Dòng cuối cùng là miêu ta khung (frame)
	+ Gồm id của frame, số đỉnh k và tọa độ k đỉnh.

Output file:
- Giống như file input nhưng tọa độ các hình đã được di chuyển về vị trí đúng.
- Số n đầu tiên là số miếng.
- n dòng tiếp theo miêu tả n miếng.
- Dòng cuối cùng là miêu tả khung.
